
# Verb Translation App

A simple static application to demonstrate verb translations and conjugations.

## Features
- Enter an Italian verb.
- Fetch translations and conjugations (mock data for demonstration).

## How to Use
1. Open `index.html` in your browser.
2. Enter a verb in Italian and click "Get Translation and Conjugation".

## Deployment
To deploy this app on GitHub Pages:
1. Create a new repository on GitHub.
2. Upload the `index.html` file.
3. Enable GitHub Pages in the repository settings.
